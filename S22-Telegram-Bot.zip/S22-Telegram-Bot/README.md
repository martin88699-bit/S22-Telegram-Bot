# S22 Telegram Bot
Set BOT_TOKEN as environment variable.
